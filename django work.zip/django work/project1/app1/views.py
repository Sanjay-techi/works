from django.shortcuts import render,redirect
from .models import Todo
from .forms import TodoForm
# Create your views here.

def add_todo(request):
    if request.method == 'POST':
        form = TodoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = TodoForm()
    return render(request, 'add_todo.html', {'form': form})

def home(request):
    todos = Todo.objects.all()
    return render(request, 'home.html', {'todos': todos})

def update(request, todo_id):
    todo = Todo.objects.get(id=todo_id)
    if request.method == 'POST':
        form = TodoForm(request.POST, instance=todo)  
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
         form = TodoForm(instance=todo)
    return render(request, 'update_todo.html', {'form': form})

def delete(request, todo_id):
    todo = Todo.objects.get(id=todo_id)
    if request.method == 'POST':
      todo.delete()
      return redirect('home')
    return render(request, 'delete_todo.html', {'todo': todo})

from django import forms
from .models import Todo

class TodoForm(forms.ModelForm):
    class Meta: # Meta class is used to specify the model and fields or extra information
        model = Todo
        fields = ['title', 'description', 'completed']